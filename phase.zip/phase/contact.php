<?php
if(isset($_GET['status']) && $_GET['status'] == "success"){
        echo "<h1 align='center'>Thanks for giving ur suggestion.</h1>";
    }
    if(isset($_GET['status']) && $_GET['status'] == "failed"){
        echo '<h1 align="center" style="color:#d96875;">Please Fill All The Form Fields.</h1>';
    }
?>
<html>
    <head>
        <title>DataCrud | Where Knowledge is power and Time is Soul</title>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/font-awesome.min.css">
        <script src="js/script.js"></script>
    </head>
    <body>
        <div class="header cf">
            <div class="logo">
                <img src="img/datacrud.png" alt="Data Crud" width="100px" />
            </div>
            <div class="nav">
                <ul class="cf">
                    <a href="index.php"><li>Home</li></a>
                    <a href="Aboutus.php"><li>About Us</li></a>
                    <a href="Mainarticles.php"><li>Articles</li></a>
                    <a href="contact.php" class="active"><li>Contact Us</li></a>
                </ul>
            </div>
        </div>
        
        <div class="content cf">
            <div class="leftbar cf">
            
               <div class="new-form">
                <form class="contact_form" action="insertcontact.php" method="post" name="contact_form">
                    <ul>
                        <li>
                             <h2>Enter Your Details</h2>
                             <span class="required_notification">Required Field are Marked *</span>
                        </li>
                        <li>
                            <label for="name">*Full Name: </label>
                            <input type="text" name="n"  placeholder="Name" required />
                        </li>
                        <li>
                            <label for="text">*Email: </label>
                            <input type="text" name="e" placeholder="Email" required />
                        </li>
                        <li>
                            <label for="text">*Phone No: </label>
                            <input type="text" name="con" placeholder="Phone"/>
                        </li>
                        <li>
                            <label for="message">*Write to us: </label>
                            <textarea name="com" cols="300" rows="10" required ></textarea>
                        </li>
                        
                        <li class="status" id="error"></li>
                        <li>
                            <button class="submit" type="submit" onclick=" return contactusValidate();">Submit Form</button>
                        </li>
                    </ul>
                </form>
            </div>
                
            </div>
            <div class="sidebar">
                <div class="social"><img src="img/social.png" alt="social" /></div>
                <div class="adv"><img src="img/ad.jpg" alt=""></div>
                <div class="advertise">Advertise Here</div>
            </div>
        </div>
        <div class="footer cf">
            <div class="lefty">
                <span>Sitemap</span>
                <ul>
                    <a href="#"><li>Home</li></a>
                    <a href="#"><li>About</li></a>
                    <a href="#"><li>Get In Touch</li></a>
                    <a href="#"><li>Programming</li></a>
                    <a href="#"><li>Contact</li></a>
                    <a href="#"><li>Java</li></a>
                    <a href="#"><li>C++</li></a>
                </ul>
            </div>
            <div class="middly">
                <span>Tweets</span>
                <ul>
                    <a href="#"><li>Nice Website</li></a>
                    <a href="#"><li>Cool Knowledge on Java</li></a>
                    <a href="#"><li>Best Programming Site</li></a>
                    <a href="#"><li>DataCrud is Awesome</li></a>
                    <a href="#"><li>Its awesome</li></a>
                    <a href="#"><li>Datacrud saved my life</li></a>
                    <a href="#"><li>Best of Luck</li></a>
                </ul>
            </div>
            <div class="righty">
                <span>Latest Posts</span>
                <ul>
                    <a href="#"><li>Tutorial On Java</li></a>
                    <a href="#"><li>Tutorial on C++</li></a>
                    <a href="#"><li>Learn Javascript Easy way</li></a>
                    <a href="#"><li>Have fun with Web Dev</li></a>
                    <a href="#"><li>Learn Web Development</li></a>
                    <a href="#"><li>Why use C#</li></a>
                    <a href="#"><li>Css3 the easy way</li></a>
                </ul>
            </div>
        </div>
    </body>
</html>