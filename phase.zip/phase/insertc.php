<?php
ob_start();
include_once("admin/db_conx.php");
$name=$_REQUEST[name];
$email=$_REQUEST[email];
$contact=$_REQUEST[contact];
$comment=$_REQUEST[comment];
$articleid=mysql_query("select a_id from tbl_article where a_id = '3' ");
$insertstring=mysql_query("insert into tbl_comment(c_name,c_email,c_contact,c_comment,date,c_a_id) values ('$name' ,'$email' , '$contact','$comment',now(),'$articleid')");

header("location:display.php?msg=record inserted");
?>