<?php
$id=mt_rand(1,100);
$date=date("Y-m-d");
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<form action="insert1.php" method="post" enctype="multipart/form-data">
<table align="center" bgcolor="#FCF" border="1" bordercolor="#003366" width="600px">
<tr><td align="center" colspan="2">Enter new blog details</td></tr>
<tr>
  <td>Blog Title</td><td><input type="text" name="b_title"/></td></tr>
<tr>
  <td>Blog Description</td><td><label for="b_descr"></label>
    <input type="text" name="b_descr" id="b_descr" /></td></tr>
<tr><td height="26">Blog Content</td><td><label for="b_content"></label>
    <textarea name="b_content" id="b_content" cols="45" rows="5"></textarea></td></tr>
<tr>
  <td>Blog Category</td><td><label for="b_cat"></label>
    <input type="text" name="b_cat" id="b_cat" /></td></tr>
<tr>
  <td>Blog Image</td><td><input type="file" name="f1"/></td></tr>
<tr><td>Registration Date</td><td><input type="text" name="regr_date"  readonly 
value="<?php echo $date;?>"/></td></tr>

<tr><td colspan="2" align="center"><input type="submit" name="submit" value="SUBMIT"/></td></tr>
</table>
</form>
</body>
</html>