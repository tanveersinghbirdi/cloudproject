<?php
ob_start();
$tmp_name=mt_rand(1,100);
include_once("db_conx.php");
$title=$_REQUEST['b_title'];
$description=$_REQUEST['b_descr'];
$content=$_REQUEST['b_content'];
$category=$_REQUEST['b_cat'];
$image=$_FILES[f1][name];
$path="images/".$image;
$sql = "insert into tbl_article(a_title,a_descr,a_content,a_image,a_date,a_category) values ('$title','$description','$content','$image',now(),'$category')";
$query = mysqli_query($db_conx,$sql);
move_uploaded_file($_FILES[f1][$tmp_name],$path);
header("location:article.php?status=inserted");

echo '<pre>
	'.print_r(var_dump($_REQUEST)).'
</pre>';
?>