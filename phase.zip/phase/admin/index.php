<?php
session_start();
ob_start();
	if(isset($_SESSION['loggerman'])){
		header("Location: article.php");
    exit();
	}
?>

<?php
  if(isset($_POST['uname'])&&isset($_POST['pword'])){
    include_once("db_conx.php");
    $user = $_POST['uname'];
    $pass = $_POST['pword'];

    $user = mysqli_real_escape_string($db_conx,$user);
    $pass = mysqli_real_escape_string($db_conx,$pass);

    $sql = "SELECT m_id,m_username FROM tbl_admin WHERE m_username='$user' AND m_password='$pass' LIMIT 1";
    $query = mysqli_query($db_conx, $sql); 
    $e_check = mysqli_num_rows($query);
    while($row  = mysqli_fetch_assoc($query)){
      $usrid = $row['m_id'];
    }
    if($e_check > 0){
      $_SESSION['loggerman'] = $usrid;
      header("Location: article.php");
      exit();
    }
    else{
   //   echo '<strong style="color:#FF0000;">Your username or password is incorrect</strong>';
    }
  }
?>


<html>
<head>
 <title>Admin Panel</title>
 <link rel="stylesheet" href="css/style.css">
</head>
<body>
 <div class="Boxify">
    <h1><strong>Welcome Back</strong> Admin</h1>
    <form action="index.php" method="post">
   <fieldset>
    <p><input type="text" name="uname" placeholder="Username"></p>
    <p><input type="password" name="pword" placeholder="Password"></p>
    <p><input type="submit" value="Login"></p>
   </fieldset>
  </form>
 </div>

</body> 
</html>