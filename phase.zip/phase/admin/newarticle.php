<?php
    include_once("header.php");
?>
<?php
if(isset($_GET['msg'])){
    $getmsg = $_GET['msg'];
    if($getmsg == "inserted"){
        echo '<span class="inserted">Record Inserted</span>';
    }
}
?>
		<div class="page">
            <div class="new-form">
                <form class="contact_form" action="insert1.php" method="post" name="contact_form" enctype="multipart/form-data">
                    <ul>
                        <li>
                             <h2>Create New Article</h2>
                             <span class="required_notification">Required Field are Marked *</span>
                        </li>
                        <li>
                            <label for="name">Article Heading:</label>
                            <input type="text" name="b_title"  placeholder="The heading of the article" required />
                        </li>
                        <li>
                            <label for="text">Description:</label>
                            <input type="text" name="b_descr" placeholder="What the article is about" required />
                        </li>
                        <li>
                            <label for="text">Category:</label>
                            <input type="text" name="b_cat" placeholder="Tags"/>
                        </li>
                        <li>
                            <label for="message">Article Content:</label>
                            <textarea name="b_content" cols="300" rows="10" required ></textarea>
                        </li>
                        <li class="fileUpload">
                            <label for="file">Browse Image:</label>
                            <input type="file" name="f1">
                        </li>
                        <li>
                            <button class="submit" type="submit">Submit Form</button>
                        </li>
                        
                    </ul>
                </form>
            </div>
		</div>
	</body>
</html>