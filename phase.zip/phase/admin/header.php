<?php
session_start();
ob_start();
    if(isset($_SESSION['loggerman']) && $_SESSION['loggerman'] != '')
    {
    }
    else{
        header("Location: index.php");
       // exit();
    }
?>
<?php
include_once("db_conx.php");
	if(isset($_POST['oldpass']) && isset($_POST['newpass'])){
		var_dump($_POST);
		$oldpass = $_POST['oldpass'];
		$newpass = $_POST['newpass'];
			$newsql = "UPDATE tbl_admin SET m_password = '$newpass' WHERE m_id=$usrnm";
			$newquery = mysqli_query($db_conx,$newsql);
			if(mysql_affected_rows()){
				header("Location: article.php?status=changedpass");
			}
			else{
				header("Location: article.php?status=changedpass");
			}
		}
	
?>
<html>
	<head>
		<title>Create new article</title>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<script>
			function changepassbla(){
				var pop = document.getElementById("clickpop");
				pop.style.display = "block";
			}
			function changepas(){
				document.Location.href = "http://localhost/ProjectBlog/admin/article.php?msg=changepass"
			}
		</script>
	</head>
	<body>

		<div class="header cf">
			<div class="logo">
				<img src="../img/datacrud.png" alt="Data Crud" width="100px" />
			</div>
			<div class="nav">
				<ul class="cf">
					<a href="article.php" class="active"><li>All Articles</li></a>
					<a href="newarticle.php"><li>Create New Articles</li></a>
					<a href="comment.php"><li>View Comments</li></a>
					<a href="#" onclick="changepassbla()";><li>Change Password</li></a>
					<a href="logout.php"><li>Logout</li></a>
				</ul>
			</div>
		</div>
		<div class="popup" id="clickpop">
			<div class="pop-head">Change Password</div>
			<form action="article.php" method="post">
	   					<fieldset>
		    				<p><input type="text" name="oldpass" placeholder="Enter Old Password"></p>
		    				<p><input type="password" name="newpass" placeholder="New Password"></p>
		    				<p><input type="submit" value="Submit"></p>
	   					</fieldset>
  					</form>
		</div>