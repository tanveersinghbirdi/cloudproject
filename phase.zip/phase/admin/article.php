<?php
    include_once("header.php");
    include_once("db_conx.php");  
?>
<?php
if (isset($_GET['status'])) {
    $stat = $_GET['status'];
    if($stat == "delete"){
        echo '<span style="font-size: 20px;color: #bb6176;font-weight: bold;position: absolute; bottom: 10px;left: 10px;">Article Deleted Successfully</span>';
    }
    if($stat == "inserted")
    {
        echo '<span style="font-size: 20px;color: #bb6176;font-weight: bold;position: absolute; bottom: 10px;left: 10px;">Article Inserted Successfully</span>';
    }
}
?>

<?php
    $sql = "SELECT * FROM tbl_article";
    $query = mysqli_query($db_conx, $sql); 
?>
		<div class="page">
			<table border="0" width="960px" style="margin: 0px auto;" cellpadding="0" cellspacing="0" class="comment-table" >
                <tr class="heading-of-table">
                    <th class="table-header-main"><a href="">Article Sr.</a></th>
                    <th class="table-header-main"><a href="">Tags</a></th>
                  	<th class="table-header-main"><a href="">Description</a></th>
                    <th class="table-header-main"><a href="">Dated</a></th>
                    <th class="table-header-comment"><a href="">Article</a></th>
                    <th class="table-header-main"><a href="">Delete</a></th>
                </tr>
                <?php
                    while ($row = mysqli_fetch_assoc($query)) {
                        echo '<tr>
                                <td>'.$row['a_id'].'</td>
                                <td>'.$row['a_category'].'</td>
								<td>'.$row['a_descr'].'</td>
                                <td>'.$row['a_date'].'</td>
                                <td>'.$row['a_title'].'</td>
                                <td><a href="delete.php?delete='.$row['a_id'].'"><i class="fa fa-times-circle deleteArticle"></i></a></td>
                            </tr>';
                    }
                ?>
            </table>
		</div>
	</body>
</html>