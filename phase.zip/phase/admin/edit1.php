<?php
ob_start();
include_once("connect.php");
$id=$_REQUEST[v];
$title=$_REQUEST[b_title];
$description=$_REQUEST[b_descr];
$content=$_REQUEST[b_content];
$category=$_REQUEST[b_cat];
$image=$_FILES[f1][name];
$rdate=$_REQUEST[regr_date];
$path="images/".$image;
$insertstring=mysql_query("update tbl_article set a_title = '$title',a_descr='$description',a_content='$content',a_image='$image',a_category='$category where a_id = $v");
move_uploaded_file($_FILES[f1][tmp_name],$path);

echo "<pre>";
print_r($_REQUEST);
echo "</pre>";
echo $image;
header("location:display.php?msg=record updated");
?>