<?php
session_start();
if(isset($_SESSION['loggerman'])){
	session_destroy();	
	echo "Successfully logged out.";
}
?>

<html>
	<head>
		<title>Logged Out Successfully.</title>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
	
	</head>
	<body>

		<div class="header cf">
			<div class="logo">
				<img src="../img/datacrud.png" alt="Data Crud" width="100px" />
			</div>
			<div class="nav">
				<ul class="cf">
					<a href="article.php" class="active"><li>All Articles</li></a>
					<a href="newarticle.php"><li>Create New Articles</li></a>
					<a href="comment.php"><li>View Comments</li></a>
					<a href="#"><li>Change Password</li></a>
				
				</ul>
			</div>
		</div>
		</body>
		</html>