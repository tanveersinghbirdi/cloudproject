<?php
include_once("connect.php");
$str="select * from tbl_article";
$selectstr=mysql_query($str);
$count=mysql_num_rows($selectstr);
$view=2;

$pages=ceil($count/$view);
?>
<table align="center" border="1">
<tr><th>Article Name</th><th>Description</th><th>Content</th><th>Registration Date</th><th>Category</th><th>Image</th><th>EDIT</th><th>DELETE</th></tr>
<?php
if(!$_REQUEST[v])
$a=0;
else
$a=$_REQUEST[v];
$x=1;
$selectstr1=mysql_query("select * from tbl_article limit $a,$view");
while($row=mysql_fetch_array($selectstr1))
{
	echo "<tr>";
	echo "<th>$row[a_title]</th>";
	echo "<th>$row[a_descr]</th>";
	echo "<th>$row[a_content]</th>";
	echo "<th>$row[a_date]</th>";
	echo "<th>$row[a_category]</th>";
	echo "<th>";
	$path="images/".$row['a_image'];
	echo "<img src='$path.' height='100px' width='100px' title='$row[stud_image]' alt='User Image'>";
	echo "</th>";
	
	echo "<th><a href='main.php?page=edit&v=$row[a_id]'>EDIT</a></th>";
	echo "<th><a href='main.php?page=delete&v=$row[a_id]'>DELETE</a></th>";
	echo "</tr>";
	$x++;
}

?>
</table>
<?php
$s=0;
echo "<center>";
for($i=1;$i<=$pages;$i++)
{
	echo "<a href='main.php?page=display&v=$s'>$i</a>&nbsp;&nbsp";
    $s=$s+$view;
}
echo "</center>";
?>
<?php
if($_REQUEST[msg])
{
	echo "<font color='#99CC00' size='+4'>".$_REQUEST[msg]."</font>";
}
?>
</body>
</html>