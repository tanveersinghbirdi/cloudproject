<?php
ob_start();
include_once("db_conx.php");
$x=$_REQUEST['delete'];
echo $x;
$str="delete from tbl_article where a_id='$x'";
$str1=mysqli_query($db_conx,$str);
header("Location: article.php?status=delete");
?>
