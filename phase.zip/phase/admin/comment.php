<?php
    include_once("header.php");
    include_once("db_conx.php");  
?>

<?php
    $sql = "SELECT * FROM tbl_comment";
    $query = mysqli_query($db_conx, $sql); 
?>
		<div class="page">
			<table border="0" width="960px" style="margin: 0px auto;" cellpadding="0" cellspacing="0" class="comment-table" >
                <tr class="heading-of-table">
                    <th class="table-header-main"><a href="">Full Name</a></th>
                    <th class="table-header-main"><a href="">Email</a></th>
                    <th class="table-header-main"><a href="">Phone</a></th>
                    <th class="table-header-comment"><a href="">Comment</a></th>
                    <th class="table-header-main"><a href="">Date</a></th>
                </tr>
                <?php
                    while($row = mysqli_fetch_assoc($query)){
                        echo '<tr>
                                <td>'.$row['c_name'].'</td>
                                <td>'.$row['c_email'].'</td>
                                <td>'.$row['c_contact'].'</td>
                                <td>'.$row['c_comment'].'</td>
                                <td>'.$row['date'].'</td>
                            </tr>';
                    }
                ?>
            </table>
		</div>
	</body>
</html>