<?php
ob_start();
include_once("admin/db_conx.php");
$name=$_REQUEST['n'];
$email=$_REQUEST['e'];
$contact=$_REQUEST['con'];
$comment=$_REQUEST['com'];

$name=mysqli_real_escape_string($db_conx,$name);
$email=mysqli_real_escape_string($db_conx,$email);
$contact=mysqli_real_escape_string($db_conx,$contact);
$comment=mysqli_real_escape_string($db_conx,$comment);

if($name == "" || $email == "" || $contact == "" || $comment == ""){
	header("location:contact.php?status=failed");
}
else{
	$myquery = mysqli_query($db_conx,"insert into tbl_contact(contact_name,contact_email,contact_phone,contact_msg) values ('$name' ,'$email' , '$contact','$comment')");
	header("location:contact.php?status=inserted");
}

?>