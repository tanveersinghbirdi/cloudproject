<?php
ob_start();
include_once("admin/db_conx.php");
if(isset($_GET['id'])){
		$aid = $_GET['id'];
		$aid = preg_replace("/[^0-9]/", "",$aid);
		$aid = mysqli_real_escape_string($db_conx, $aid);
		$sql = "SELECT * FROM tbl_article WHERE a_id = $aid";
    	$query = mysqli_query($db_conx, $sql); 
	}


if(isset($_GET['id'])&&isset($_GET['n'])&&isset($_GET['e'])&&isset($_GET['con'])&&isset($_GET['com'])){
$idget=$_GET['id'];
$name=$_GET['n'];
$email=$_GET['e'];
$contact=$_GET['con'];
$comment=$_GET['com'];

$idget = mysqli_real_escape_string($db_conx,$idget);
$name = mysqli_real_escape_string($db_conx,$name);
$email = mysqli_real_escape_string($db_conx,$email);
$contact = mysqli_real_escape_string($db_conx,$contact);
$comment = mysqli_real_escape_string($db_conx,$comment);

$myquery = mysqli_query($db_conx,"insert into tbl_comment(c_name,c_email,c_contact,c_comment,date,c_a_id) values ('$name' ,'$email' , '$contact','$comment',now(),'$idget')");
echo true;
exit();
}

?>


<?php

	$commentsql = "SELECT * FROM tbl_comment WHERE c_a_id = $aid";
	$commentquery = mysqli_query($db_conx,$commentsql);
	$allcomments = mysqli_num_rows($commentquery);
?>
<html>
	<head>
		<title>DataCrud | Where Knowledge is power and Time is Soul</title>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<script src="js/script.js"></script>
	</head>
	<body>
		<div class="header cf">
			<div class="logo">
				<img src="img/datacrud.png" alt="Data Crud" width="100px" />
			</div>
			<div class="nav">
				<ul class="cf">
					<a href="index.php"><li>Home</li></a>
					<a href="Aboutus.php" ><li>About Us</li></a>
					<a href="Mainarticles.php" class="active"><li>Articles</li></a>
					<a href="contact.php"><li>Contact Us</li></a>
		</ul>
			</div>
		</div>
		<div class="content cf">
			<div class="leftbar">



			<?php 
				while($row = mysqli_fetch_assoc($query))
				{
					$month = date( "F", strtotime( $row['a_date'] ) );
					$date = date( "j", strtotime( $row['a_date'] ) );
					echo '


						<div class="article-header cf">
					<div class="article-date">
						<span class="date-num">'.$date.'</span><span class="date-month">'.$month.'</span>
					</div>
					<div class="article-main-heading">
						<span class="art-head">'.$row['a_title'].'</span>
						<div><span class="art-autor">Admin</span> <span class="art-tags"><i class="fa fa-code"></i>'.$row['a_category'].'</span> <span class="art-comments"><i class="fa fa-flash"></i> '.$allcomments . ' Comments</span></div>
					</div>
				</div>	
				<div class="article-content">
					<h3>'.$row['a_descr'].'</h3>
					<p>'.$row['a_content'].'</p>
					<img src="admin/images/'.$row['a_image'].'" alt="">

				</div>

					';




				}
			?>





				<div class="comment-system">
					<div class="TotalCommentCount"> <?php echo $allcomments . ' Comments';  ?></div>
					<ul class="comment-list">
						

					<?php
						while($arr = mysqli_fetch_assoc($commentquery)){
							echo '<li>
							<div class="comment-box">
								<img src="img/anon36.png" alt="">
								<div class="comment-tab">
									<div class="comment-info">
										<span class="name1">'.$arr['c_name'].'</span>
										<span class="dated1">@'.$arr['date'].'</span>
										<span class="email1">'.$arr['c_email'].'</span>
									</div>
									<div class="comment-input">'.$arr['c_comment'].'</div>
								</div>
							</div>
						</li>';
						}
					?>

						
					</ul>
					<div class="EnterNewComment">
						<div class="newcomment-header">Enter a new Comment: </div>
	
							<div class="inputbox cf">
								<div class="input-left">
									<input type="text" id="full_name" name="name" placeholder="Full Name">
								</div>
								<div class="input-right">
									<input type="email" id="mail" name="email" placeholder="Email ID">
								</div>
								<div class="input-right">
									<input type="phone" id="contact" name="contact" placeholder="Enter Contact">
								</div>
							</div>
							<textarea cols="61" rows="6" id="comment" name="comment" placeholder="Comment on this Article..."></textarea>
							<div id="error"></div>
							<div class="button-to-post" onclick="sendComment(<?php echo $aid;?>);">Post</div>

					</div>
				</div>
			</div>
		</div>
		<div class="footer cf">
			<div class="lefty">
				<span>Sitemap</span>
				<ul>
					<a href="#"><li>Home</li></a>
					<a href="#"><li>About</li></a>
					<a href="#"><li>Get In Touch</li></a>
					<a href="#"><li>Programming</li></a>
					<a href="#"><li>Contact</li></a>
					<a href="#"><li>Java</li></a>
					<a href="#"><li>C++</li></a>
				</ul>
			</div>
			<div class="middly">
				<span>Tweets</span>
				<ul>
					<a href="#"><li>Nice Website</li></a>
					<a href="#"><li>Cool Knowledge on Java</li></a>
					<a href="#"><li>Best Programming Site</li></a>
					<a href="#"><li>DataCrud is Awesome</li></a>
					<a href="#"><li>Its awesome</li></a>
					<a href="#"><li>Datacrud saved my life</li></a>
					<a href="#"><li>Best of Luck</li></a>
				</ul>
			</div>
			<div class="righty">
				<span>Latest Posts</span>
				<ul>
					<a href="#"><li>Tutorial On Java</li></a>
					<a href="#"><li>Tutorial on C++</li></a>
					<a href="#"><li>Learn Javascript Easy way</li></a>
					<a href="#"><li>Have fun with Web Dev</li></a>
					<a href="#"><li>Learn Web Development</li></a>
					<a href="#"><li>Why use C#</li></a>
					<a href="#"><li>Css3 the easy way</li></a>
				</ul>
			</div>
		</div>
	</body>
</html>