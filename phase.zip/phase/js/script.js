var image1 = new Image()
  image1.src = "images/6.png";
var image2 = new Image()
  image2.src = "images/5.png";
var image3 = new Image()
  image3.src = "images/3.png";
var image4 = new Image()
  image4.src = "images/4.png";

function sendComment(id) {
    var f = document.getElementById("full_name").value;
    var errordiv = document.getElementById("error");
    errordiv.innerHTML = "";
    var x = document.getElementById("mail").value;
    var attherate = x.indexOf("@");
    var contact = document.getElementById("contact").value;
    var phoneno = /^\d{10}$/;
    var comment = document.getElementById("comment").value;
    var dotnote = x.lastIndexOf(".");
    var full_flag = 1;
    var email_flag = 1;
    var contact_flag = 1;
    var comment_flag = 1;
    if(f == ""){
      errordiv.innerHTML += "<br/>Name Is Not Valid";
      full_flag = 0;
    }
    if (attherate< 1 || dotnote<attherate+2 || dotnote+2>=x.length) {
      errordiv.innerHTML += "<br/>Please Enter Correct Email";
      email_flag = 0;    
    }
    if(contact == "" || !contact.match(phoneno) ){
      errordiv.innerHTML += "<br/>Please Enter Your Phone Number";
      contact_flag = 0;
    }
    if(comment ==""){
      errordiv.innerHTML += "<br/>Enter Something in your comment";
      comment_flag = 0;
    }



    // var name = document.getElementById("full_name").value;
    // var contact = document.getElementById("contact").value;
    // var comment = document.getElementById("comment").value;
    // var email = document.getElementById("mail").value;
  if (id== "" || full_flag===0 || email_flag===0 || contact_flag===0 || comment_flag===0) {
    document.getElementById("error").innerHTML+="</br> Error in your form";
    return;
  }
  if (window.XMLHttpRequest) {
    xmlhttp=new XMLHttpRequest();
  } else {
    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
  xmlhttp.onreadystatechange=function() {
    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
      var accepted_flag = xmlhttp.responseText;
      if(accepted_flag){
        alert("Comment Added Successfully");
        location.reload(); 
        document.getElementById("full_name").value = "";
        document.getElementById("mail").value = "";
        document.getElementById("contact").value = "";
        document.getElementById("comment").value = "";
      }
    }
  }
  xmlhttp.open("GET","article.php?id="+id+"&n="+f+"&e="+x+"&con="+contact+"&com="+comment,true);
  xmlhttp.send();
}

var step=1;
        function slideit()
        {
            document.images.slide.src = eval("image"+step+".src");
            if(step<4)
                step++;
            else
                step=1;
            setTimeout("slideit()",2500);
        }
        


function contactusValidate() {
    var f = document.getElementById("n").value;
    var errordiv = document.getElementById("error");
    errordiv.innerHTML = "";
    var x = document.getElementById("e").value;
    var attherate = x.indexOf("@");
    var contact = document.getElementById("con").value;
    var phoneno = /^\d{10}$/;
    var comment = document.getElementById("com").value;
    var dotnote = x.lastIndexOf(".");
    var full_flag = 1;
    var email_flag = 1;
    var contact_flag = 1;
    var comment_flag = 1;
    if(f == ""){
      errordiv.innerHTML += "<br/>Name Is Not Valid";
      full_flag = 0;
    }
    if (attherate< 1 || dotnote<attherate+2 || dotnote+2>=x.length) {
      errordiv.innerHTML += "<br/>Please Enter Correct Email";
      email_flag = 0;    
    }
    if(contact == "" || !contact.match(phoneno) ){
      errordiv.innerHTML += "<br/>Please Enter Your Phone Number";
      contact_flag = 0;
    }
    if(comment ==""){
      errordiv.innerHTML += "<br/>Enter Something in your comment";
      comment_flag = 0;
    }
    if (id== "" || full_flag===0 || email_flag===0 || contact_flag===0 || comment_flag===0) {
        return false;
    }
    else {
      return true;
    }
}