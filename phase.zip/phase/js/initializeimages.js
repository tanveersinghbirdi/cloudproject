var image1 = new Image()
	image1.src = "images/1.png";
var image2 = new Image()
	image2.src = "images/2.png";
var image3 = new Image()
	image3.src = "images/3.png";
var image4 = new Image()
	image4.src = "images/4.png";