<?php
    include_once("admin/db_conx.php");  
?>
<?php
    $sql = "SELECT * FROM tbl_article";
    $query = mysqli_query($db_conx, $sql); 
	$query1 = mysqli_query($db_conx, $sql); 
?>
<html>
	<head>
		<title>DataCrud | Where Knowledge is power and Time is Soul</title>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">

		<script src="js/script.js"></script>
		<script type="text/javascript">
var image1 = new Image()
image1.src = "images/1.png"
var image2 = new Image()
image2.src = "images/2.png"
var image3 = new Image()
image3.src = "images/3.png"
var image4 = new Image()
image4.src = "images/4.png"
</script>
	</head>
	<body>
		<div class="header cf">
			<div class="logo">
				<img src="img/datacrud.png" alt="Data Crud" width="100px" />
			</div>
			<div class="nav">
				<ul class="cf">
					<a href="index.php"><li>Home</li></a>
					<a href="Aboutus.php" class="active"><li>About Us</li></a>
					<a href="Mainarticles.php"><li>Articles</li></a>
					<a href="contact.php"><li>Contact Us</li></a>
				</ul>
			</div>
		</div>
		<div class="slideshow cf">
			<div class="span8">
				<div class="ssimg">
					<img src="img/1.png" alt="1.png" name="slide">
				</div>
			</div>
			<div class="span4">
				<ul>
				    <?php
				        $i = 0;
	                    while ($row = mysqli_fetch_assoc($query)) {
	                    	$i++;
	                    	if($i<7){
							echo '<a href="#"><li><div class="oflow">
									<img src="admin/images/'.$row['a_image'].'" alt="">
									<div class="info">
										<span>'.$row['a_title'].'</span>
										<p>'.$row['a_descr'].'</p>
									</div> </div></li></a>';
							}
						}							
					?>
				</ul>
			</div>
		</div>
		<div class="content cf">
			<div class="leftbar cf">
				<table border="0" width="650px" style="margin: 0px auto;" cellpadding="0" cellspacing="0" class="comment-table" >
                <tr class="heading-of-table">
                    <th class="table-header-main">About Us</th>
              
                </tr>
                <tr>
                	<td>
                		<img src="images/about.png" width="650px" height="650px" alt="aboutus image">
                	</td>
                </tr>
                <tr>
                	<td> This site is developed for the programmers and developers which are involved in the Web development and software development profession.
                	</td>
                </tr>
                <tr>
                
                	<td> In this site. the admin can create a new article which may include the information about the new technology or the developers can ask for help in there project.
                		The theme of the site is much similar to stackoverflow site where the professionals help the new comers in their programming code.
                </td>
                </tr>
                <tr>
                
                	<td> Once the article is uploaded by the admin. The visitors of the site can write there code or any help in the comments section corresponding to the article.
                </td>
                </tr>
                   <tr>
                
                	<td> We can add more functionality to our site by introducing new features such as user can add it's own article and user admin controls can also be given to the user.
                </td>
                </tr>
            </table>
				
			</div>
			<div class="sidebar">
				<div class="social"><img src="img/social.png" alt="social" /></div>
				<div class="adv"><img src="img/ad.jpg" alt=""></div>
				
			</div>
		</div>
		<div class="footer cf">
			<div class="lefty">
				<span>Sitemap</span>
				<ul>
					<a href="#"><li>Home</li></a>
					<a href="#"><li>About</li></a>
					<a href="#"><li>Get In Touch</li></a>
					<a href="#"><li>Programming</li></a>
					<a href="#"><li>Contact</li></a>
					<a href="#"><li>Java</li></a>
					<a href="#"><li>C++</li></a>
				</ul>
			</div>
			<div class="middly">
				<span>Tweets</span>
				<ul>
					<a href="#"><li>Nice Website</li></a>
					<a href="#"><li>Cool Knowledge on Java</li></a>
					<a href="#"><li>Best Programming Site</li></a>
					<a href="#"><li>DataCrud is Awesome</li></a>
					<a href="#"><li>Its awesome</li></a>
					<a href="#"><li>Datacrud saved my life</li></a>
					<a href="#"><li>Best of Luck</li></a>
				</ul>
			</div>
			<div class="righty">
				<span>Latest Posts</span>
				<ul>
					<a href="#"><li>Tutorial On Java</li></a>
					<a href="#"><li>Tutorial on C++</li></a>
					<a href="#"><li>Learn Javascript Easy way</li></a>
					<a href="#"><li>Have fun with Web Dev</li></a>
					<a href="#"><li>Learn Web Development</li></a>
					<a href="#"><li>Why use C#</li></a>
					<a href="#"><li>Css3 the easy way</li></a>
				</ul>
			</div>
		</div>
<script type="text/javascript">
        var step=1;
        function slideit()
        {
            document.images.slide.src = eval("image"+step+".src");
            if(step<4)
                step++;
            else
                step=1;
            setTimeout("slideit()",2500);
        }
        slideit();
</script>
	</body>
</html>