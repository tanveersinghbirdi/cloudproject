<?php
    include_once("admin/db_conx.php");  
?>
<?php
    $sql = "SELECT * FROM tbl_article";
    $query = mysqli_query($db_conx, $sql); 
	$query1 = mysqli_query($db_conx, $sql); 
?>
<html>
	<head>
		<title>DataCrud | Where Knowledge is power and Time is Soul</title>
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/font-awesome.min.css">
		<script src="js/script.js"></script>
		<script type="text/javascript">
var image1 = new Image()
image1.src = "images/1.png"
var image2 = new Image()
image2.src = "images/2.png"
var image3 = new Image()
image3.src = "images/3.png"
var image4 = new Image()
image4.src = "images/4.png"
</script>
	</head>
	<body>
		<div class="header cf">
			<div class="logo">
				<img src="img/datacrud.png" alt="Data Crud" width="100px" />
			</div>
			<div class="nav">
				<ul class="cf">
					<a href="index.php" ><li>Home</li></a>
					<a href="Aboutus.php"><li>About Us</li></a>
					<a href="Mainarticles.php" class="active"><li>Articles</li></a>
					<a href="contact.php"><li>Contact Us</li></a>
				</ul>
			</div>
		</div>
		
		<div class="content cf">
			<div class="leftbar cf">
            
				<?php
                    while ($row = mysqli_fetch_assoc($query1)) {
                       echo '<div class="boxer cf">
					<div class="headwa">
						<h3>'.$row['a_title'].' </h3>
						<div class="lower cf">
							<div class="tagger">Posted in <span>'.$row['a_category'].'</span></div>
							<div class="cmtr"><span>Total Comments</span></div>
						</div>
					</div>
					<div class="imager">
						<img src="admin/images/'.$row['a_image'].'" alt="">
					</div>
					<div class="para">
						<p>'.$row['a_content'].'</p>
					</div>
					<div class="buttoner">
						<button class="btn" onClick="javascript:location.href=\'article.php?id='.$row['a_id'].'\'">Read More</button>
					</div>
				</div>';
				}
                ?>
				
			</div>
			<div class="sidebar">
				<div class="social"><img src="img/social.png" alt="social" /></div>
				<div class="adv"><img src="img/ad.jpg" alt=""></div>
				<div class="advertise">Advertise Here</div>
			</div>
		</div>
		<div class="footer cf">
			<div class="lefty">
				<span>Sitemap</span>
				<ul>
					<a href="#"><li>Home</li></a>
					<a href="#"><li>About</li></a>
					<a href="#"><li>Get In Touch</li></a>
					<a href="#"><li>Programming</li></a>
					<a href="#"><li>Contact</li></a>
					<a href="#"><li>Java</li></a>
					<a href="#"><li>C++</li></a>
				</ul>
			</div>
			<div class="middly">
				<span>Tweets</span>
				<ul>
					<a href="#"><li>Nice Website</li></a>
					<a href="#"><li>Cool Knowledge on Java</li></a>
					<a href="#"><li>Best Programming Site</li></a>
					<a href="#"><li>DataCrud is Awesome</li></a>
					<a href="#"><li>Its awesome</li></a>
					<a href="#"><li>Datacrud saved my life</li></a>
					<a href="#"><li>Best of Luck</li></a>
				</ul>
			</div>
			<div class="righty">
				<span>Latest Posts</span>
				<ul>
					<a href="#"><li>Tutorial On Java</li></a>
					<a href="#"><li>Tutorial on C++</li></a>
					<a href="#"><li>Learn Javascript Easy way</li></a>
					<a href="#"><li>Have fun with Web Dev</li></a>
					<a href="#"><li>Learn Web Development</li></a>
					<a href="#"><li>Why use C#</li></a>
					<a href="#"><li>Css3 the easy way</li></a>
				</ul>
			</div>
		</div>
<script type="text/javascript">
        var step=1;
        function slideit()
        {
            document.images.slide.src = eval("image"+step+".src");
            if(step<4)
                step++;
            else
                step=1;
            setTimeout("slideit()",2500);
        }
        slideit();
</script>
	</body>
</html>